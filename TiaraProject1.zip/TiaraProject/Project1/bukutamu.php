<?php
include 'koneksi.php';

// Proses simpan data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama  = htmlspecialchars($_POST['nama']);
    $email = htmlspecialchars($_POST['email']);
    $pesan = htmlspecialchars($_POST['pesan']);

    $sql = "INSERT INTO bukutamu (nama, email, pesan) VALUES ('$nama', '$email', '$pesan')";
    mysqli_query($conn, $sql);

    // Hindari submit ulang saat refresh
    header("Location: bukutamu.php");
    exit;
}

// Ambil data buku tamu
$data = mysqli_query($conn, "SELECT * FROM bukutamu ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Buku Tamu - Ara Skincare</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #fffaf9;
      margin: 0;
      padding: 20px;
    }

    .container {
      max-width: 700px;
      margin: auto;
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    h2 {
      color: #f2a5b5;
      text-align: center;
    }

    form {
      margin-bottom: 30px;
    }

    input, textarea {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 14px;
    }

    button {
      background-color: #f2a5b5;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    button:hover {
      background-color: #e08fa2;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 14px;
    }

    th, td {
      border: 1px solid #ddd;
      padding: 10px;
    }

    th {
      background-color: #f2a5b5;
      color: white;
      text-align: left;
    }

    td {
      vertical-align: top;
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Buku Tamu Ara Skincare</h2>
    
    <!-- Form Input -->
    <form action="" method="post">
      <input type="text" name="nama" placeholder="Nama Lengkap" required>
      <input type="email" name="email" placeholder="Email" required>
      <textarea name="pesan" rows="4" placeholder="Pesan atau Kesan Anda..." required></textarea>
      <button type="submit">Kirim</button>
    </form>

    <!-- Tabel Data -->
    <h3>Data Buku Tamu:</h3>
    <table>
      <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Email</th>
        <th>Pesan</th>
      </tr>
      <?php
      $no = 1;
      while($row = mysqli_fetch_assoc($data)) {
        echo "<tr>
                <td>$no</td>
                <td>{$row['nama']}</td>
                <td>{$row['email']}</td>
                <td>{$row['pesan']}</td>
              </tr>";
        $no++;
      }
      ?>
    </table>
  </div>
<div style="text-align:center; margin-top: 10px;">
      <a href="Project1.htm">&larr; Kembali ke Beranda</a>
    </div>
</body>
</html>
